--create table machineType (machineTypeId integer, typeName varchar(35), unit varchar(20), cost double);
--create table storageType  (storageTypeId integer, typeName varchar(35), unit varchar(20), cost double);
--create table employeeType (empTypeId integer,  typeName varchar(35),  cost double);
--create table machine (machineId integer  machineTypeId varchar(20),  location varchar(20),  appId varchar(20));
--create table storage ( storageId integer,  storageTypeId varchar(20),  size integer,  appId varchar(20));
--create table appDetails ( id integer,  appId  varchar(20), appName varchar(20), contact  varchar(20),  appManager  varchar(40),  STIL  varchar(40), SMT  varchar(40), orgName  varchar(50));
--create table machineRequest (  machineId  integer, machineTypeId  integer,  qty integer,  qtyType integer,  details  varchar(255),  appId  varchar(20), approvalStatus  varchar(20));
--




